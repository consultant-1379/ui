# Java

## Usage
./java.sh

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/base/java