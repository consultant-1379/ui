# Schema Registry
Schema Registry uses a REST API, with JSON payload, providing a way to store/retrieve 
Avro schemas to be used by other components. 
Integration with Model Service is required.

## Usage
./schema-registry.sh <ZOOKEEPER_PORT_2181_TCP_ADDR> <KAFKA_ADVERTISED_HOST_NAME>

## Example
./schema-registry.sh 10.32.226.236 10.32.226.236

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/base/schema-registry
docker run -d --name schemaRegistry -e "ZOOKEEPER_PORT_2181_TCP_ADDR=<IP>" -e "ZOOKEEPER_PORT_2181_TCP_PORT=2181" -e "KAFKA_ADVERTISED_HOST_NAME=<IP>" -p 8090:8090 confluent/schema-registry