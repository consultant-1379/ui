#!/bin/bash
if [ "$#" -ne 2 ]; then
  echo "Usage: $0 ZOOKEEPER_PORT_2181_TCP_ADDR KAFKA_ADVERTISED_HOST_NAME" >&2
  exit 1
fi

docker pull armdocker.rnd.ericsson.se/aia/base/schema-registry
docker run -d --name schemaRegistry -e "ZOOKEEPER_PORT_2181_TCP_ADDR=$1" -e "ZOOKEEPER_PORT_2181_TCP_PORT=2181" -e "KAFKA_ADVERTISED_HOST_NAME=$2" -p 8090:8090 armdocker.rnd.ericsson.se/aia/base/schema-registry

