# Grafana
Grafana provides a powerful and elegant way to create, explore, and share dashboards and data with your team and the world.

## Usage
./grafana.sh

## Pull/Run Example
docker pull armdocker.rnd.ericsson.se/aia/base/grafana
docker run -d --name grafana -p 80:80 -p 81:81 -p 8126:8126 -p 8125:8125/udp armdocker.rnd.ericsson.se/aia/base/grafana