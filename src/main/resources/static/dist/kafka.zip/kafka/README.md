# Kafka
Kafka is a distributed messaging system implementing publish-subscribe and providing high throughput. 
Producers send messages directly to a broker, each partition has a broker acting as leader. 
Consumers issue a “fetch” to the broker leading the partition containing the data it wants to consume. 
The consumer specifies an offset within the partition, thus allowing them to specify how far back they 
want to receive data from.

## Usage
./kafka.sh <ZOOKEEPER_PORT_2181_TCP_ADDR> <KAFKA_ADVERTISED_HOST_NAME>

## Example
./kafka.sh 10.32.226.236 10.32.226.236

## Pull/Run Example
docker pull armdocker.rnd.ericsson.se/aia/base/kafka
docker run -d -p 9092:9092 -e "ZOOKEEPER_PORT_2181_TCP_ADDR=$1" -e "ZOOKEEPER_PORT_2181_TCP_PORT=2181" -e "KAFKA_ADVERTISED_HOST_NAME=$2" armdocker.rnd.ericsson.se/aia/base/kafka

