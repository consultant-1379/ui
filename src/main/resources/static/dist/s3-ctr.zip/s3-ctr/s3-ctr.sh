#!/bin/bash
docker pull armdocker.rnd.ericsson.se/aia/asr/s3-ctr
