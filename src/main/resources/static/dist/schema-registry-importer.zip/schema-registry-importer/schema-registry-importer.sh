#!/bin/sh
if [ "$#" -ne 2 ]; then
  if [ "$#" -ne 4 ]; then
  echo "Usage for Import: $0 <AVRO SCHEMA DIR> <SCHEMA REGISRTY ADDRESS>" >&2
  echo "Usage for Conversion and Import: $0 <AVRO SCHEMA DIR> <SCHEMA REGISRTY ADDRESS> <XMLS DIR> <FEATURE> " >&2
  exit 1
  fi
  docker pull armdocker.rnd.ericsson.se/aia/schema-registry-importer
  docker run -it --rm -v $1:/avro-schemas -v $3:/xmls  armdocker.rnd.ericsson.se/aia/schema-registry-importer -dir=/avro-schemas -registry=$2 -xmlDirs=/xmls -feature=$4
fi

docker pull armdocker.rnd.ericsson.se/aia/schema-registry-importer
docker run -it --rm -v $1://avro-schemas armdocker.rnd.ericsson.se/aia/schema-registry-importer -dir=//avro-schemas -registry=$2

