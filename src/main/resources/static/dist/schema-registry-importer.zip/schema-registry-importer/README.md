# Schema Registry Importer
A command line tool to import avro schemas into the Schema Registry service
Additional funcitonality includes conversion of xmls to avro schemas

## Import Usage
./schema-registry-importer.sh <AVRO SCHEMA DIR> <SCHEMA REGISRTY ADDRESS>

## Import Example
./schema-registry-importer.sh /tmp/avro-schema http://atrcxb2560-1.athtem.eei.ericsson.se:8081/

## Convert & Import Usage
./schema-registry-importer.sh <AVRO SCHEMA DIR> <SCHEMA REGISRTY ADDRESS> <XMLS DIR> <FEATURE>

## Convert & Import Example
./schema-registry-importer.sh /tmp/avro-schema http://atrcxb2560-1.athtem.eei.ericsson.se:8081/ /tmp/xmls/ ctum