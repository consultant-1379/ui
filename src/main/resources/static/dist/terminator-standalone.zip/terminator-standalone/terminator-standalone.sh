#!/bin/bash
docker pull armdocker.rnd.ericsson.se/aia/terminator-standalone
