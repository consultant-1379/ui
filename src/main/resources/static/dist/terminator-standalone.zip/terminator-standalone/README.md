# Terminator Standalone

## Usage
./terminator-standalone.sh

## Pull Example
docker pull armdocker.rnd.ericsson.se/aia/terminator-standalone