#!/bin/bash

if [ "$#" -ne 2 ]; then
  echo "Usage: $0 TYPE STREAMING_HOST" >&2
  exit 1
fi

docker pull armdocker.rnd.ericsson.se/aia/simulators/playbacker/playbacker-single-rop
docker run armdocker.rnd.ericsson.se/aia/simulators/playbacker/playbacker-single-rop $1 $2
